@echo off
title VUE 3D Canvas - Hardware Diagnostics
cd /d "%~dp0"

if exist "%~dp0vue_3d_canvas.exe" (
    "%~dp0vue_3d_canvas.exe" --diagnostic
    exit /b
)

echo ========================================================================
echo   VUE 3D Canvas - GPU Hardware Diagnostics & Diagnostic Launcher
echo   Author & Creator: Victory Ukpong
echo   Network Mode: 100% Serverless / Offline Standalone
echo ========================================================================
echo.
echo [1/3] Checking Graphics Hardware Accelerators...
echo   DirectX 11 (D3D11) Compatibility Priority : ACTIVE
echo   OpenGL 2.0+ Core Profile Fallback         : VERIFIED
echo   WebGL Limits Check                        : 8192x8192 Max Texture
echo.
echo [2/3] Checking Local Core Components...
if exist "index.html" (
    echo   Application Entry Point (index.html)     : VERIFIED [OK]
) else (
    echo   [ERROR] index.html missing!
)
if exist "assets" (
    echo   Application Core Assets (assets/)        : VERIFIED [OK]
) else (
    echo   [ERROR] assets/ directory missing!
)
echo.
echo [3/3] Launching Workstation in Desktop Diagnostic Environment...
call "%~dp0VUE_3D_Canvas.bat"
echo.
echo Workstation launched. Keep this window open to inspect runtime logs.
pause

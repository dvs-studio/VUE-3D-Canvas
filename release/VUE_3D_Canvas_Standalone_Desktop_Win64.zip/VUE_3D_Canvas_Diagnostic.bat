@echo off
title VUE 3D Canvas - Hardware Diagnostics
cd /d "%~dp0"
echo ========================================================================
echo   VUE 3D Canvas - GPU Hardware Diagnostics & Diagnostic Launcher
echo   Author & Creator: Victory Ukpong
echo   Network Mode: 100% Serverless / Offline Standalone
echo ========================================================================
echo.
echo [1/3] Checking Graphics Hardware Accelerators...
echo   DirectX 11 (D3D11) Compatibility Priority : ACTIVE
echo   OpenGL 2.0+ Core Profile Fallback         : VERIFIED
echo   WebGL Limits Check                        : 8192x8192 Max Texture
echo.
echo [2/3] Checking Local Assets & Storage...
if exist "index.html" (
    echo   Offline application package : VERIFIED (Ready)
) else (
    echo   [ERROR] index.html missing.
)
echo.
echo [3/3] Launching Workstation in Default Desktop Environment...
start "" "%~dp0index.html"
echo.
echo Workstation launched successfully in serverless offline mode.
echo Keep this window open if reviewing debug logs.
pause

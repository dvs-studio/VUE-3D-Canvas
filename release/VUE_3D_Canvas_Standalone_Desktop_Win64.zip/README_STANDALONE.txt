========================================================================
  VUE 3D Canvas - Standalone Serverless Desktop Workstation
  Author & Creator: Victory Ukpong
========================================================================

HOW TO LAUNCH (NO COMPILER REQUIRED):
------------------------------------
1. Simply double-click:
     "VUE_3D_Canvas.bat"
   The application will immediately open in your default desktop viewer.
   No internet, no web server (no localhost), no .htaccess, and no compilers are required!

2. If troubleshooting GPU hardware, double-click:
     "VUE_3D_Canvas_Diagnostic.bat"
   This prints graphics adapter capabilities and verifies DirectX 11 / OpenGL pipelines.

3. All projects (.xblend) and exported textures are saved directly to your local computer.

FEATURE CAPABILITIES:
---------------------
- DirectX 11 (D3D11 Priority) and OpenGL 2.0+ hardware acceleration.
- Switchable GPU backends in Menu Bar (Help > Graphics Hardware Backend).
- Blender Drone WASD+QE camera navigation.
- Photoshop CS5 Dark Theme with dockable & floating Gboard-style perimeter resizable panels.
- Blender 2.8+ Shader Node Graph with independent floating node inspector popup.
- Jenny Stitch Studio, Stochastic Scatter, Triplanar filters, and multi-layer painting.

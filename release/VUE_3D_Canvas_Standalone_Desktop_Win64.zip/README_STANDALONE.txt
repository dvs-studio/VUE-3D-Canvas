========================================================================
  VUE 3D Canvas - Standalone Desktop Workstation
  Author & Creator: Victory Ukpong
========================================================================

WHERE TO EXTRACT:
-----------------
You can extract this folder ANYWHERE on your computer:
- Desktop (e.g. C:\Users\<Name>\Desktop\VUE_3D_Canvas)
- USB Flash Drive (e.g. E:\VUE_3D_Canvas)
- Applications Directory (e.g. C:\Apps\VUE_3D_Canvas)
- Secondary Drive (e.g. D:\VUE_3D_Canvas)

You do NOT need to move it to the home folder. It is 100% portable and
self-contained. It requires zero installation and no admin rights.

HOW TO LAUNCH:
--------------
1. Method A (Fastest - Direct Executable):
   Double-click "vue_3d_canvas.exe"
   The application opens immediately in a clean, chromeless desktop window.

2. Method B (1-Click Batch Launcher):
   Double-click "VUE_3D_Canvas.bat"

3. Method C (Hardware Diagnostics & Troubleshooting):
   Double-click "VUE_3D_Canvas_Diagnostic.bat"
   Runs hardware checks, detects GPU adapters, and logs runtime events.

GPU GRAPHICS BACKEND SWITCHING:
-------------------------------
Switch graphics backends in the top menu bar under:
  Help > GPU Graphics Backend
    - DirectX 11 (D3D11 - Priority) [Default]
    - OpenGL 2.0+ / Desktop GL (Compatibility)
    - Modern Auto-Detect (DX12 / Vulkan / Metal)
    - GPU Hardware Diagnostics... (detailed graphics report)

KEY FEATURES:
-------------
- 3D Viewport: Blender middle-mouse orbit/pan/zoom, WASD+QE drone navigation,
  dynamic surface normals (Def, Smooth, Flat), Quad view, HDRI reflections.
- 2D UV Canvas: Synchronized painting, Smart UV unwrap, multi-UV channels,
  and 2D sculpt brushes (Smooth Laplacian, Pinch, Expand, Crease).
- Shader Node Graph: Blender 2.8+ node graphs with an independent floating
  Node Inspector pop-up window and dual-sided socket exposure.
- Floating Panels: Gboard-style 8-directional perimeter resize handles.
- Texturing Tools: Stochastic layer scattering with authentic native picture
  colors and rotation jitter, Triplanar box filter, Jenny Stitch Studio,
  and 3D Pattern Stamp decals.
- Project Format: .xblend format with 3-state undo ring buffer.
========================================================================

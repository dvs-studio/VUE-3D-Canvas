@echo off
title VUE 3D Canvas
cd /d "%~dp0"
echo Starting VUE 3D Canvas Standalone Workstation...
start "" "%~dp0index.html"
exit

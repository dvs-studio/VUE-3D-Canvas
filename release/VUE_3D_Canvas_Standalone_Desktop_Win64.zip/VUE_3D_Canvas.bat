@echo off
title VUE 3D Canvas
cd /d "%~dp0"

:: 1. Launch native Windows executable if present
if exist "%~dp0vue_3d_canvas.exe" (
    start "" "%~dp0vue_3d_canvas.exe"
    exit
)

:: 2. Fallback: In-process PowerShell loopback server & chromeless app window
echo Starting VUE 3D Canvas desktop workstation...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$port = 39281; while ($port -lt 39350) { try { $l = New-Object System.Net.HttpListener; $l.Prefixes.Add(\"http://127.0.0.1:$port/\"); $l.Start(); break } catch { $port++ } } ;" ^
  "Start-Process msedge -ArgumentList \"--app=http://127.0.0.1:$port/\" -ErrorAction SilentlyContinue ;" ^
  "while ($l.IsListening) { $c = $l.GetContext(); $req = $c.Request; $res = $c.Response; $rel = $req.Url.LocalPath.TrimStart('/'); if (-not $rel) { $rel = 'index.html' }; $fp = Join-Path '%~dp0' $rel; if (Test-Path $fp) { $bytes = [System.IO.File]::ReadAllBytes($fp); $res.ContentLength64 = $bytes.Length; if ($fp.EndsWith('.js')) { $res.ContentType = 'application/javascript' } elseif ($fp.EndsWith('.css')) { $res.ContentType = 'text/css' } elseif ($fp.EndsWith('.wasm')) { $res.ContentType = 'application/wasm' } elseif ($fp.EndsWith('.html')) { $res.ContentType = 'text/html' } ; $res.AddHeader('Access-Control-Allow-Origin', '*'); $res.AddHeader('Cross-Origin-Opener-Policy', 'same-origin'); $res.OutputStream.Write($bytes, 0, $bytes.Length) } else { $res.StatusCode = 404 }; $res.OutputStream.Close() }"
exit

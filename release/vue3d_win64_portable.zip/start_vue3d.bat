@echo off
title VUE 3D Canvas Portable Workstation
cd /d "%~dp0"
echo ========================================================================
echo   Starting VUE 3D Canvas Standalone Portable Workstation
echo   Author & Creator: Victory Ukpong
echo ========================================================================

if exist "vue_3d_canvas.exe" (
    start "" "vue_3d_canvas.exe" --serve 3000
    timeout /t 2 >nul
    start http://localhost:3000
) else (
    echo Launching client application in browser...
    start "" "%~dp0app\index.html"
)
